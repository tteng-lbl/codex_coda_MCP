#!/usr/bin/env bash
set -euo pipefail

bundle_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
plugin_src="${bundle_dir}/plugins/coda-mcp"
plugin_dest="${HOME}/plugins/coda-mcp"
marketplace_path="${HOME}/.agents/plugins/marketplace.json"

if [[ ! -f "${plugin_src}/.codex-plugin/plugin.json" ]]; then
  echo "Could not find plugin manifest at ${plugin_src}/.codex-plugin/plugin.json" >&2
  exit 1
fi

python3 -m json.tool "${plugin_src}/.codex-plugin/plugin.json" >/dev/null
python3 -m json.tool "${plugin_src}/.mcp.json" >/dev/null

mkdir -p "${HOME}/plugins" "$(dirname "${marketplace_path}")"

if [[ -e "${plugin_dest}" ]]; then
  backup="${plugin_dest}.backup.$(date +%Y%m%d%H%M%S)"
  mv "${plugin_dest}" "${backup}"
  echo "Backed up existing plugin to ${backup}"
fi

cp -R "${plugin_src}" "${plugin_dest}"

python3 - "${marketplace_path}" <<'PY'
import json
import sys
from pathlib import Path

marketplace_path = Path(sys.argv[1])
entry = {
    "name": "coda-mcp",
    "source": {
        "source": "local",
        "path": "./plugins/coda-mcp",
    },
    "policy": {
        "installation": "AVAILABLE",
        "authentication": "ON_INSTALL",
    },
    "category": "Productivity",
}

if marketplace_path.exists():
    payload = json.loads(marketplace_path.read_text())
else:
    payload = {
        "name": "local",
        "interface": {
            "displayName": "Local Plugins",
        },
        "plugins": [],
    }

if not isinstance(payload, dict):
    raise SystemExit(f"{marketplace_path} must contain a JSON object")

payload.setdefault("name", "local")
payload.setdefault("interface", {"displayName": "Local Plugins"})
plugins = payload.setdefault("plugins", [])
if not isinstance(plugins, list):
    raise SystemExit(f"{marketplace_path} field 'plugins' must be an array")

for index, plugin in enumerate(plugins):
    if isinstance(plugin, dict) and plugin.get("name") == "coda-mcp":
        plugins[index] = entry
        break
else:
    plugins.append(entry)

marketplace_path.parent.mkdir(parents=True, exist_ok=True)
marketplace_path.write_text(json.dumps(payload, indent=2) + "\n")
PY

python3 -m json.tool "${marketplace_path}" >/dev/null

echo "Installed Coda MCP plugin to ${plugin_dest}"
echo "Updated marketplace at ${marketplace_path}"
echo "Restart Codex, then install/enable Coda MCP from the local marketplace."
