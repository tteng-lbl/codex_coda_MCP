# Coda MCP Codex Plugin

This plugin connects Codex to Coda's remote MCP endpoint:

```text
https://coda.io/apis/mcp
```

## Setup

No access token setup should be needed for the default flow.

The plugin registers Coda as a direct remote HTTP MCP server. On first use, Codex should open a browser-based authorization flow. Sign in to Coda with your normal account, including Google sign-in if that is how you access Coda, then approve the MCP connection.

Coda documents browser OAuth for clients that support remote MCP authentication. Their current Codex CLI instructions still use a personal access token, so this plugin keeps a manual token launcher only as a fallback for environments where browser OAuth is not accepted.

## Optional Token Fallback

Use a token only when browser OAuth is unavailable, when you need a specific Coda token scope, or when you explicitly want non-browser setup.

1. Create a Coda API token from your Coda account page.
2. Set the token restriction type to `MCP`.
3. Choose the least-privilege access scope needed: read only, write only, or read and write.
4. Store the token in macOS Keychain.

Use Keychain Access to create a new password item:

- Keychain Item Name: `codex-coda-mcp`
- Account Name: your macOS username
- Password: your Coda MCP token

This avoids putting the token in shell history, plugin files, or command-line arguments.

For non-macOS systems or temporary local stdio testing, the launcher can also read `CODA_MCP_AUTH_TOKEN` from the Codex process environment. Avoid typing token assignments directly into an interactive shell. Use your local secret-management flow and restart Codex so it inherits the variable.

To force one manual launcher auth path, set `CODA_MCP_AUTH_MODE` before starting Codex:

- `auto`: default; use a configured token when present, otherwise browser OAuth.
- `oauth`: always use browser OAuth and ignore token sources.
- `token`: require Keychain or `CODA_MCP_AUTH_TOKEN`.

Never paste Coda tokens into chat, commit them to files, or store them in `.env` files inside this plugin.

When the manual token fallback is used, the launcher passes authentication to `mcp-remote` through an environment-interpolated header so the token is not expanded into process arguments. The installed plugin's primary MCP registration does not require this launcher.

## Files

- `.codex-plugin/plugin.json` contains plugin metadata.
- `.mcp.json` registers the Coda remote HTTP MCP server.
- `scripts/coda-mcp-server.sh` is a manual fallback launcher for stdio testing.
- `skills/coda-mcp/SKILL.md` gives Codex setup and usage guidance.

## Notes

Coda documents that OAuth connections use read and write scope, while personal access tokens can be scoped to read only, write only, or read and write. If authentication fails with a 401-style token error, create a new token using restriction type `MCP`.

`mcp-remote` supports debug logs, but this plugin does not enable them. Scrub any logs before sharing them because auth failures and HTTP traces can include sensitive details.
