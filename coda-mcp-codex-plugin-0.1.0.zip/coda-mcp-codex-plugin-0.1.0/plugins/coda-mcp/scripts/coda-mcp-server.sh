#!/usr/bin/env bash
set -euo pipefail

CODA_MCP_URL="https://coda.io/apis/mcp"
AUTH_MODE="${CODA_MCP_AUTH_MODE:-auto}"
KEYCHAIN_SERVICE="codex-coda-mcp"
KEYCHAIN_ACCOUNT="${USER:-}"
if [[ -z "${KEYCHAIN_ACCOUNT}" ]] && command -v id >/dev/null 2>&1; then
  KEYCHAIN_ACCOUNT="$(id -un 2>/dev/null || true)"
fi

case "${AUTH_MODE}" in
  auto | oauth | token) ;;
  *)
    cat >&2 <<'EOF'
Invalid CODA_MCP_AUTH_MODE.

Use one of:
  auto   Prefer browser OAuth, but use a configured token when present.
  oauth  Always use browser OAuth.
  token  Require a token from Keychain or CODA_MCP_AUTH_TOKEN.
EOF
    exit 1
    ;;
esac

start_browser_oauth() {
  exec npx -y mcp-remote "${CODA_MCP_URL}"
}

if [[ "${AUTH_MODE}" == "oauth" ]]; then
  start_browser_oauth
fi

coda_token=""
if [[ "$(uname -s 2>/dev/null || true)" == "Darwin" ]] \
  && command -v security >/dev/null 2>&1 \
  && [[ -n "${KEYCHAIN_ACCOUNT}" ]]; then
  coda_token="$(
    security find-generic-password \
      -s "${KEYCHAIN_SERVICE}" \
      -a "${KEYCHAIN_ACCOUNT}" \
      -w 2>/dev/null || true
  )"
fi

if [[ -z "${coda_token}" && -n "${CODA_MCP_AUTH_TOKEN:-}" ]]; then
  coda_token="${CODA_MCP_AUTH_TOKEN}"
fi

if [[ -z "${coda_token}" ]]; then
  if [[ "${AUTH_MODE}" == "auto" ]]; then
    start_browser_oauth
  fi

  cat >&2 <<'EOF'
Missing Coda MCP credentials.

Preferred token setup:
  Add a macOS Keychain password item named "codex-coda-mcp".
  Set the account to your macOS username and the password to your Coda MCP token.

Portable fallback:
  Start Codex with CODA_MCP_AUTH_TOKEN already set in its environment.

Create a Coda API token with restriction type "MCP" and the minimum scope needed.
Do not paste tokens into chat or commit them to files.
EOF
  exit 1
fi

export CODA_MCP_AUTH_HEADER="Bearer ${coda_token}"
unset coda_token

exec npx -y mcp-remote "${CODA_MCP_URL}" \
  --header 'Authorization:${CODA_MCP_AUTH_HEADER}' \
  --silent
