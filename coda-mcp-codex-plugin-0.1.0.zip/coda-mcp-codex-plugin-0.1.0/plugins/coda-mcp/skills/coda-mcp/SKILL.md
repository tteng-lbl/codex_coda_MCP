---
name: coda-mcp
description: Use when the user wants Codex to read, write, update, search, or manage Coda docs through the Coda MCP server, or asks about Coda MCP authentication.
---

# Coda MCP

This plugin connects Codex to Coda's remote MCP endpoint:

```text
https://coda.io/apis/mcp
```

## Authentication

The plugin registers Coda as a direct remote HTTP MCP server. On first use, Codex may open a browser authorization flow; the user can sign in using their normal Coda login, including Google sign-in.

Coda documents browser OAuth for remote MCP clients such as Claude Code and Cursor. Their current Codex CLI instructions still use personal access tokens, so this plugin keeps a manual stdio token fallback for cases where OAuth is unavailable or when the user needs scoped token access.

Token fallback sources, in order:

1. macOS Keychain item named `codex-coda-mcp`, with account set to the user's macOS username.
2. `CODA_MCP_AUTH_TOKEN` in the Codex process environment.

Manual fallback authentication mode can be forced with `CODA_MCP_AUTH_MODE`:

- `auto`: default; use a configured token when present, otherwise browser OAuth.
- `oauth`: always use browser OAuth.
- `token`: require Keychain or `CODA_MCP_AUTH_TOKEN`.

When helping a user set up token fallback, tell them to create a Coda API token from their Coda account page with restriction type `MCP`. Coda lets personal access tokens choose read only, write only, or read and write access; recommend the least-privilege scope for the task. Coda documents OAuth connections as read and write.

Prefer Keychain Access GUI setup so the token does not land in shell history. Use the environment-variable fallback only for local or temporary workflows. Do not ask the user to paste the token into chat. Do not suggest committing tokens, saving tokens in plugin files, or adding tokens to `.env` files inside this plugin.

When manual token fallback is used, the launcher passes the token to `mcp-remote` through an environment-interpolated authorization header so the token is not expanded into process arguments. Debug logging is intentionally off by default; warn users to scrub logs before sharing them.

## Usage Guidance

When Coda MCP tools are available, use them for Coda docs instead of asking the user to manually copy table data, page content, or document structure. Confirm the target doc/page/table before making broad write operations.

If the Coda MCP server fails with a 401-style authentication error, suggest creating a new Coda token with restriction type `MCP`; Coda documents that non-MCP token restrictions can cause authorization failures.
