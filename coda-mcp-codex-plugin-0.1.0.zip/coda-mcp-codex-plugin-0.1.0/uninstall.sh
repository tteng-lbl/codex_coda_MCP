#!/usr/bin/env bash
set -euo pipefail

plugin_dest="${HOME}/plugins/coda-mcp"
marketplace_path="${HOME}/.agents/plugins/marketplace.json"

rm -rf "${plugin_dest}"

if [[ -f "${marketplace_path}" ]]; then
  python3 - "${marketplace_path}" <<'PY'
import json
import sys
from pathlib import Path

marketplace_path = Path(sys.argv[1])
payload = json.loads(marketplace_path.read_text())
plugins = payload.get("plugins", [])
if isinstance(plugins, list):
    payload["plugins"] = [
        plugin for plugin in plugins
        if not (isinstance(plugin, dict) and plugin.get("name") == "coda-mcp")
    ]
marketplace_path.write_text(json.dumps(payload, indent=2) + "\n")
PY
fi

echo "Removed Coda MCP plugin files and marketplace entry."
echo "Restart Codex to unload the plugin."
